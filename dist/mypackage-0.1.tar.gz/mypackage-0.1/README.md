# mypackage
This library was created as an example of how publish your own Python package.

## building this package locally
`python setup.py sdict`

## installing this package from Github
`pip install git+https://ithub.com/jayeshm/example-python-package.git`

## updating this package from Github
`pip install --upgrade git+https://ithub.com/jayeshm/example-python-package.git`
